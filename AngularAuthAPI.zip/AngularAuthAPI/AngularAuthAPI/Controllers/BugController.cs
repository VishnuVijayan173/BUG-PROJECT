﻿using AngularAuthAPI.Context;
using AngularAuthAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AngularAuthAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BugController : ControllerBase
    {
        private readonly AppDbContext _authContext;
        public BugController(AppDbContext appDbContext)
        {
            _authContext = appDbContext;
        }
        [HttpGet]

        public async Task<ActionResult<IEnumerable<Bug>>> GetBugs()
        {
            if (_authContext.Bugs == null)
            {
                return NotFound();
            }
            return Ok(await _authContext.Bugs.ToListAsync());
        }

        [HttpGet("{id}")]

        public async Task<ActionResult<Bug>> GetBug(int id)
        {
            if (_authContext.Bugs == null)
            {
                return NotFound();
            }
            var bug = await _authContext.Bugs.FindAsync(id);
            if (bug == null)
            {
                return NotFound();
            }
            return bug;
        }
        [HttpPost]

        public async Task<ActionResult<Bug>> PostBug(Bug bug)
        {
            _authContext.Bugs.Add(bug);
            await _authContext.SaveChangesAsync();

            return CreatedAtAction(nameof(GetBug), new { id = bug.BugID }, bug);
        }

        [HttpPut]

        public async Task<ActionResult> PutBug(int id, Bug bug)
        {
            if (id != bug.BugID)
            {
                return BadRequest();
            }
            _authContext.Entry(bug).State = EntityState.Modified;

            try
            {
                await _authContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BugAvailable(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return Ok();
        }
        private bool BugAvailable(int id)
        {
            return (_authContext.Bugs?.Any(x => x.BugID == id)).GetValueOrDefault();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<Bug>> DeleteBug(int id)
        {
            if (_authContext.Bugs == null)
            {
                return NotFound();
            }
            var bug = await _authContext.Bugs.FindAsync(id);
            if (bug == null)
            {
                return NotFound();
            }
            _authContext.Bugs.Remove(bug);
            await _authContext.SaveChangesAsync();
            return Ok();
        }
        //[HttpDelete]
        //[Route("{id}")]
        //public async Task<IActionResult> DeleteBug([FromRoute] int id)
        //{
        //    var bug = await _authContext.Bugs.FindAsync(id);
        //    if (bug == null)
        //    {
        //        return NotFound();
        //    }
        //    _authContext.Bugs.Remove(bug);
        //    await _authContext.SaveChangesAsync();
        //    return Ok(bug);
        //}
    }
}
