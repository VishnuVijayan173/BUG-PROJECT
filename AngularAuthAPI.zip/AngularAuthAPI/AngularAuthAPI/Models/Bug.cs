﻿namespace AngularAuthAPI.Models
{
    public class Bug
    {
        public int BugID { get; set; }
        public string BugName { get; set; }
        public string BugDescription { get; set; } 
        public string BugStatus { get; set; }
        public string Project { get; set; }
        public string RaisedBy { get; set; }

        public List<User> users { get; set; }
        public User user { get; set; }
    }
}
