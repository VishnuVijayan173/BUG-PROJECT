import React, { useEffect, useState } from 'react';
import { Table, ButtonToolbar } from 'react-bootstrap';
import { FaEdit } from 'react-icons/fa';
import { RiDeleteBin5Line } from 'react-icons/ri';
import AddBugModal from './AddBugModal';
import axios from 'axios';
import {  GetBugs } from '../services/BugServices';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { toast ,ToastContainer} from 'react-toastify';
import {useNavigate} from 'react-router-dom';


const Manage = () => {
  const [data, setData] = useState([]);
  const [addModalShow, setAddModalShow] = useState(false);
  const [editBug, setEditBug] = useState({});
  const [isUpdated, setIsUpdated] = useState(false);
  const [show, setShow] = useState(false);



  const [editBugId, setEditBugId] = useState();
  const [editBugName, setEditBugName] = useState("");
  const [editBugDescription, setEditBugDescription] = useState("");
  const [editBugStatus, setEditBugStatus] = useState("");
  const [editProject, setEditProject] = useState("");
  const [editRaisedBy, setEditRaisedBy] = useState("");

  const navigate = useNavigate();

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);




  useEffect(() => {
    axios.get('https://localhost:44306/api/Bug')
      .then(res => setData(res.data))
      .catch(err => console.log(err));
  }, []);

  const handleUpdate = (bugID) => {
    handleShow();
    axios.get(`https://localhost:44306/api/Bug/${bugID}`)
    .then((result)=>{
      console.log (result)
      setEditBugId(result.data.bugID);
      
      
      setEditBugName(result.data.bugName);
      setEditBugDescription(result.data.bugDescription);
      setEditBugStatus(result.data.bugStatus);
      setEditProject(result.data.project);
      setEditRaisedBy(result.data.raisedBy);

  })
  .catch((error)=> {
    console.log(error);
  })

   
  };

  const handleAdd = (e) => {
    e.preventDefault();
    setAddModalShow(true);
  };

  const handleDelete = (bugID) => {
    if(window.confirm("Are you sure to delete")==true){
      axios.delete(`https://localhost:44306/api/Bug/${bugID}`)
      .then((result)=>{
        if(result.status === 200){
          toast.success('Bug has been deleted');
          navigate("/dashboard/bugs");


        }
      })
      .catch((error)=>{
        toast.error(error);
      })
        }
  };

  const  handleEdit =(editBugId)=>{
    console.log(editBugId)
    const url=`https://localhost:44306/api/Bug?id=${editBugId}`;
    const data = {
      "bugID": editBugId,
      "bugName": editBugName,
    "bugDescription": editBugDescription,
    "bugStatus": editBugStatus,
    "project": editProject,
    "raisedBy": editRaisedBy 
    }
    axios.put(url,data)
      .then((result)=>{
        if(result.status === 200){
        console.log(result);
        GetBugs();
        }
        }).catch((error)=>{
          toast.error(error);
        })
        


  }

  let AddModelClose = () => setAddModalShow(false);
  return (
    <div className="container-fluid side-container">
      <ToastContainer/>
      <div className="row side-row">
        <p id="manage"></p>
        <Table striped bordered hover className="react-bootstrap-table" id="dataTable">
          <thead>
            <tr>
              <th >BugID</th>
              <th>Bug Name</th>
              <th>Bug Description</th>
              <th>Bug Satus</th>
              <th>Project</th>
              <th>Raised By</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {data.map((bug) =>
              <tr key={bug.bugID}>
                <td>{bug.bugID}</td>
                <td>{bug.bugName}</td>
                <td>{bug.bugDescription}</td>
                <td>{bug.bugStatus}</td>
                <td>{bug.project}</td>
                <td>{bug.raisedBy}</td>
                <td>
                  <Button className="mr-2" variant="danger"
                    onClick={() => handleDelete(bug.bugID)}>
                    <RiDeleteBin5Line />
                  </Button>
                  <span>&nbsp;&nbsp;&nbsp;</span>
                  <Button className="mr-2"
                    onClick={() => handleUpdate(bug.bugID) } >
                    <FaEdit />
                  </Button>
                  
                </td>
              </tr>
            )}
              </tbody>

        </Table>
        <ButtonToolbar>
          <Button variant="primary" onClick={handleAdd}>
            Add Bug
          </Button>
          <AddBugModal show={addModalShow} setUpdated={setIsUpdated}
            onHide={AddModelClose}></AddBugModal>


        </ButtonToolbar>
        <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Edit details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="container">
          <div>
          <label>Bug Name</label>
            <input type="text" className="form-control" placeholder="Enter BugName"
            value={editBugName} onChange={(e)=> setEditBugName(e.target.value)}
            />
            </div>
          <div>
          <label>Bug Description</label>
            <input type="text" className="form-control" placeholder="Enter description"
            value={editBugDescription} onChange={(e)=> setEditBugDescription(e.target.value)}
            />
            </div>
          <div>
          <label>Bug Status</label>
            <input type="text" className="form-control" placeholder="Enter Status"
            value={editBugStatus} onChange={(e)=> setEditBugStatus(e.target.value)}
            />
            </div>
          <div>
          <label>Project</label>
            <input type="text" className="form-control" placeholder="Enter Project"
            value={editProject} onChange={(e)=> setEditProject(e.target.value)}
            />
            </div>
          <div>
          <label>Raised By</label>
            <input type="text" className="form-control" placeholder="Raised By"
            value={editRaisedBy} onChange={(e)=> setEditRaisedBy(e.target.value)}
            />
            </div> 
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" value={editBugId} onClick={handleEdit(editBugId)}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
      </div>
    </div>
  );
};

export default Manage;