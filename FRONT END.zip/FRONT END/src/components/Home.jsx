import React from "react";
import '../services/logo.png'
import { Card, CardImg } from "reactstrap";
 

const Home = () => {
    return (
        <div className="d-flex justify-content-center">
      <Card>
        <h1>Welcome to BUG TRACKER</h1>
      </Card>
    </div>
        
    )
};

export default Home;