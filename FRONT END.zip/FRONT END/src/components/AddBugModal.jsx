import { clear } from '@testing-library/user-event/dist/clear';
import axios from 'axios';
import React,{ useEffect, useState }from 'react';
import {Modal, Col, Row, Form, Button} from 'react-bootstrap';
import {FormControl, FormGroup, FormLabel} from 'react-bootstrap';
import { addBug, getBugs } from '../services/BugServices';
import {ToastContainer, toast} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


const AddBugModal = (props) => {
    const [bugNameReg, setBugNameReg] = useState("");
    const [bugDescriptionReg, setBugDescriptionReg] = useState("");
    const [bugStatusReg, setBugStatusReg] = useState("");
    const [projectreg, setProjectreg] = useState("");
    const [raisedByReg, setRaisedByReg] = useState("");

const handleSubmit = (e) => {
  e.preventDefault();
  axios.post("https://localhost:44306/api/Bug", {
    bugName: bugNameReg,
    bugDescription: bugDescriptionReg,
    bugStatus: bugStatusReg,
    project: projectreg,
    raisedBy: raisedByReg,
  }).then((response) => {
    console.log(response);
    toast.success('Added Successfully');
    window.location.href="http://localhost:3000/dashboard/bugs"
  });
};

    return(
        <div className="container">

            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered >

                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Fill In Bug Information
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Row>
                        <Col sm={6}>
                            <Form onSubmit={handleSubmit}>
                                <Form.Group controlId="bugName">
                                    <Form.Label>Bug Name</Form.Label>
                                    <Form.Control type="text"
                                     name="bugName"  required 
                                     placeholder="" 
                                     onChange={(e) => {
                                        setBugNameReg(e.target.value)
                                     }}/>
                            </Form.Group>
                            <Form.Group controlId="bugDescription">
                                    <Form.Label>Bug Description</Form.Label>
                                    <Form.Control type="text" name="bugDescription"
                                     required 
                                     placeholder=""  
                                     onChange={(e) => {
                                        setBugDescriptionReg(e.target.value)
                                     }}/>
                            </Form.Group>
                            <Form.Group controlId="bugStatus">
                                    <Form.Label>Bug Status</Form.Label>
                                    <Form.Control type="text"
                                     name="bugStatus" required
                                      placeholder=""  
                                      onChange={(e) => {
                                        setBugStatusReg(e.target.value)
                                      }}/>
                            </Form.Group>
                            <Form.Group controlId="project">
                                    <Form.Label>Project</Form.Label>
                                    <Form.Control type="text"
                                     name="project" required 
                                     placeholder=""  
                                     onChange={(e) => {
                                        setProjectreg(e.target.value)
                                     }}/>
                            </Form.Group>
                            <Form.Group controlId="raisedBy">
                                    <Form.Label>Raised By</Form.Label>
                                    <Form.Control type="text"
                                     name="raisedBy" required 
                                     placeholder="" 
                                     onChange={(e) => {
                                        setRaisedByReg(e.target.value)
                                    }}
                                        />
                            </Form.Group>
                            <Form.Group>
                                <p></p>
                                <Button variant="primary" type="submit">
                                    Submit
                                </Button>
                            </Form.Group>
                            </Form>
                        </Col>
                    </Row>
                </Modal.Body>
                <Modal.Footer>
                <Button variant="danger" type="submit" onClick={props.onHide}>
                        Close
                </Button>

                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default AddBugModal;