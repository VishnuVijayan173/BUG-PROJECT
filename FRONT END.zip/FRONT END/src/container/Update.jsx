import { Table } from 'react-bootstrap';
import { getBugs } from '../services/BugServices';
import '../App.css';


import { useState, useEffect } from 'react';
import React, { Component } from 'react';
import { render } from '@testing-library/react';
import { RestaurantMenu } from '@mui/icons-material';
const Update = ({ id }) => {
    const [inputValues, setInputValues] = useState({});
    useEffect(() => {
      async function fetchData() {
        try {
          const res = await fetch(`https://localhost:44306/api/Bug/${id}`);
          const data = await res.json();
          setInputValues(data);
        } catch (e) {
          console.log(e);
        }
      }
      fetchData();
    }, [id]);
  
    const handleChange = (e) => {
      setInputValues({ ...inputValues, [e.target.name]: e.target.value });
    };
  
    const handleSave = (e) => {
      e.preventDefault();
      // Save the input values to the backend
      fetch(`https://localhost:44306/api/Bug/${id}`, {
        method: 'PUT',
        body: JSON.stringify(inputValues),
        headers: {
          'Content-Type': 'application/json'
        }
      })
        .then(res => res.json())
        .then(data => {
          console.log('Success:', data);
        })
        .catch(error => {
          console.error('Error:', error);
        });
    };
  
    return (
      <>
        <form onSubmit={handleSave}>
          <label htmlFor="bugName">Bug Name:</label>
          <input
            type="text"
            id="bugName"
            name="bugName"
            value={inputValues.bugName}
            onChange={handleChange}
          />
          <br />
          <label htmlFor="bugDescription">Bug Description:</label>
          <input
            type="text"
            id="bugDescription"
            name="bugDescription"
            value={inputValues.bugDescription}
            onChange={handleChange}
          />
          <br />
          <label htmlFor="bugStatus">Bug Status:</label>
          <input
            type="text"
            id="bugStatus"
            name="bugStatus"
            value={inputValues.bugStatus}
            onChange={handleChange}
          />
          <br />
          <label htmlFor="project">Project:</label>
          <input
            type="text"
            id="project"
            name="project"
            value={inputValues.project}
            onChange={handleChange}
          />
          <br />
          <label htmlFor="raisedBy">Raised By:</label>
          <input
            type="text"
            id="raisedBy"
            name="raisedBy"
            value={inputValues.raisedBy}
            onChange={handleChange}
          />
          <br />
          <button type="submit">Save</button>
        </form>
      </>
    );
  };

// export default class Update extends Component {
//   state = {
//     bugs: []
//   }



//   componentDidMount() {
//     getBugs()
//     .then(data => {
//       this.setState((state, props) => ({
//         bugs: data
//       }));
//     })
//     .catch((error)=>{
//       console.log(error)
//     })
//   }

//   componentDidUpdate(prevProps, prevState) {
  
//       console.log('This runs when the count property on state changes',this.state.bugs);
      
//   }

 

//   render() {
//     return (
//       <div {style="background-color: black; padding: 20px;"}>
//            <Table striped bordered hover className="react-bootstrap-table" id="dataTable">
//            <thead>
//                <tr>
//                <th >BugID</th>
//                <th>Bug Name</th>
//                <th>Bug Description</th>
//                <th>Bug Status</th>
//                <th>Project</th>
//                <th>Raised By</th>
//                </tr>
//            </thead>
//            <tbody>
//                {this.state.bugs?.map((bug) =>
//                 <tr key={bug.bugID}>
//                   <td inputMode='text'>{bug.bugID}</td>
//                   <td>{bug.bugName}</td>
//                   <td>{bug.bugDescription}</td>
//                   <td>{bug.bugStatus}</td>
//                   <td>{bug.project}</td>
//                   <td>{bug.raisedBy}</td>
//                   <td>
                    
//                   </td>
//               </tr>
              
//              )}
//            </tbody>
//        </Table>
//        </div>
//     );
//   }
// }

//  const Update= ()=>{
// const{id}=useParams();

// const [bugName, setBugName]=useState("");
// const [bugDescription, setBugDescription]=useState("");
// const [bugstatus, setBugstatus]=useState("");
// const [project, setProject]=useState("");
// const [raisedBy, setRaisedBy]=useState("");

// useEffect(()=>{
//     axios.get(`$id`).then((response)=>{
//         console.log(response);
//         console.log(response.data[0].bugName)
//         setBugName(response.data[0].bugName)
//         setBugDescription(response.data[0].bugDescription)
//         setBugstatus(response.data[0].bugstatus)
//         setProject(response.data[0].project)
//         setRaisedBy(response.data[0].raisedBy)

//     })
// },[]);

// const handleUpdate = (e) => {
//     e.preventDefault();

//     let bug = (bugName,bugDescription ,bugstatus,project,raisedBy)
//     console.log(bug);

//     var request = new XMLHttpRequest();

//     request.onload=function(){
//         if(this.readyState===4 && this.status===200){
//             console.log(this);
//         }
//     }
//     request.open("PUT",`${id}`);
//     request.setRequestHeader('Content-type','application/json;charset=UTF-8');
//     console.log(JSON.stringify(bug))
//     request.send(JSON.stringify(bug));
//     window.location.href="http://localhost:3000/dashboard"
// }
// return (
// <div style="background-color: black; padding: 20px;">
//   <table>
//     <tr>
//       <td>
//         <form>
//           <label for="input1">Input 1:</label>
//           <input type="text" id="input1" name="input1"/><br/>
          
//           <label for="input2">Input 2:</label>
//           <input type="text" id="input2" name="input2"/><br/>
          
//           <label for="input3">Input 3:</label>
//           <input type="text" id="input3" name="input3"/><br>
          
//           <label for="input4">Input 4:</label>
//           <input type="text" id="input4" name="input4"/><br/>
          
//           <label for="input5">Input 5:</label>
//           <input type="text" id="input5" name="input5"/><br/>
          
//           <button type="submit">Submit</button>
//         </form>
//       </td>
//     </tr>
//   </table>
// </div>
// )};
export default Update;
